export interface EditBrandTypes {
  name_ar: string;
  name_en: string;
  country: string;
  meta_title: string;
  meta_description: string;
  logo?: string;
}
